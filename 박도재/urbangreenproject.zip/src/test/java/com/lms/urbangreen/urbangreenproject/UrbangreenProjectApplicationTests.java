package com.lms.urbangreen.urbangreenproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UrbangreenProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
