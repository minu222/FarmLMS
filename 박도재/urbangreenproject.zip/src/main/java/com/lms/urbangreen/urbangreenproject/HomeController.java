package com.lms.urbangreen.urbangreenproject;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
@RequiredArgsConstructor
public class HomeController {

    @GetMapping({"/", "/main"})
    public String showHomePage(org.springframework.ui.Model model) {
        model.addAttribute("courses", java.util.Collections.emptyList());
        return "main/main";
    }

    @GetMapping("/faq")
    public String faq() {
        return "main/faq";  // 화면 출력
    }

    @GetMapping("/privacy")
    public String privacy() {
        return "main/privacy";  // 화면 출력
    }

    @GetMapping("/terms")
    public String terms() {
        return "main/terms";  // 화면 출력
    }
}