package com.lms.urbangreen.urbangreenproject.board.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class GameController {

    @GetMapping("/main/game")
    public String gamePage() {
        return "main/game";
    }
}