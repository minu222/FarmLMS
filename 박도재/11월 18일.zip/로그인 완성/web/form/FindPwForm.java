package com.lms.urbangreen.urbangreenproject.user.web.form;

import lombok.Data;

@Data
public class FindPwForm {
    private String id;
    private String email;

}