// 기존 네 함수 구조를 유지하되, 데이터 접근을 ChatAPI로 교체

let selectedRoom = null;
let joinedRooms = [], otherRooms = [];

document.addEventListener('DOMContentLoaded', async () => {
    await refreshRooms();
    await renderUsers();
});

async function refreshRooms(){
    const data = await ChatAPI.listRooms();
    joinedRooms = data.joined || [];
    otherRooms = data.others || [];
    renderRoomLists();
}

function renderRoomLists(){
    const joinedList = document.getElementById('joinedList');
    const otherList  = document.getElementById('otherList');
    joinedList.innerHTML = ''; otherList.innerHTML = '';

    function addItem(r, isJoined){
        const el = document.createElement('div');
        el.className = `room-item ${selectedRoom && selectedRoom.id===r.id ? 'active':''}`;
        el.dataset.roomId = r.id;
        el.innerHTML = `
      <div class="room-avatar">${r.name.slice(0,1)}</div>
      <div class="room-body">
        <div class="room-title">
          <span>${r.name}</span>
          ${isJoined?'<span class="badge-joined">참여중</span>':''}
        </div>
        <div class="room-meta">${(r.desc||'')} · ${r.members}명</div>
      </div>
    `;
        el.addEventListener('click', ()=> isJoined ? openRoom(r.id) : openJoinModal(r.id));
        (isJoined? joinedList : otherList).appendChild(el);
    }

    joinedRooms.forEach(r=>addItem(r, true));
    otherRooms.forEach(r=>addItem(r, false));
}

async function openRoom(roomId){
    selectedRoom = [...joinedRooms, ...otherRooms].find(r=>r.id===roomId);
    document.querySelectorAll('.room-item').forEach(el=>el.classList.remove('active'));
    const activeItem=document.querySelector(`.room-item[data-room-id="${roomId}"]`);
    if(activeItem) activeItem.classList.add('active');

    document.getElementById('activeRoomName').textContent = selectedRoom.name;
    const isJoined = !!joinedRooms.find(r=>r.id===roomId);
    document.getElementById('leaveBtn').style.display = isJoined ? 'block' : 'none';

    const view = document.getElementById('chatView');
    view.innerHTML = '';
    const msgs = await ChatAPI.getMessages(roomId, 50);
    msgs.forEach(m => appendMessage(m));

    const input=document.getElementById('chatInput'), send=document.getElementById('sendBtn');
    input.disabled = send.disabled = !isJoined;
    input.value = '';
    view.scrollTop = view.scrollHeight;

    // 실시간 구독
    if(isJoined){
        if(window._roomSub) window._roomSub.unsubscribe();
        window._roomSub = await ChatAPI.subscribeRoom(roomId, (m)=> appendMessage(m));
    }
}

function appendMessage(m){
    const view=document.getElementById('chatView');
    const div=document.createElement('div');
    div.className = `msg ${m.mine ? 'me':'other'}`;
    div.innerHTML = m.mine ? (m.content) : (`<div class="author">${m.senderName}</div>${m.content}`);
    view.appendChild(div);
    view.scrollTop = view.scrollHeight;
}

async function leaveRoom(){
    if(!selectedRoom) return;
    if(!confirm(`"${selectedRoom.name}" 채팅방에서 나가시겠습니까?`)) return;
    await ChatAPI.leaveRoom(selectedRoom.id);
    selectedRoom = null;
    document.getElementById('activeRoomName').textContent = '채팅방을 선택하세요';
    document.getElementById('leaveBtn').style.display='none';
    document.getElementById('chatView').innerHTML='';
    document.getElementById('chatInput').disabled=true;
    document.getElementById('sendBtn').disabled=true;
    await refreshRooms();
    alert('채팅방에서 나갔습니다.');
}

document.getElementById('sendBtn').addEventListener('click', sendMessage);
document.getElementById('chatInput').addEventListener('keydown', e=>{
    if(e.key==='Enter' && !e.shiftKey){ e.preventDefault(); sendMessage(); }
});

async function sendMessage(){
    if(!selectedRoom) return;
    const input=document.getElementById('chatInput');
    const text=input.value.trim();
    if(!text) return;
    await ChatAPI.sendMessage(selectedRoom.id, text);
    // 내가 쓴 건 즉시 내 화면에도 보이게
    appendMessage({mine:true, content:text});
    input.value='';
}

let pendingJoinRoom = null;
function openJoinModal(roomId){
    pendingJoinRoom = otherRooms.find(r=>r.id===roomId);
    document.querySelector('.modal-room-name').textContent = pendingJoinRoom.name;
    document.querySelector('.modal-room-desc').textContent = pendingJoinRoom.desc || '';
    document.getElementById('joinModal').classList.add('active');
}
function closeModal(){
    pendingJoinRoom = null;
    document.getElementById('joinModal').classList.remove('active');
}
async function confirmJoin(){
    if(!pendingJoinRoom) return;
    await ChatAPI.joinRoom(pendingJoinRoom.id);
    closeModal();
    await refreshRooms();
    await openRoom(pendingJoinRoom.id);
}

function openCreateModal(){
    document.getElementById('newRoomName').value='';
    document.getElementById('newRoomDesc').value='';
    document.getElementById('createModal').classList.add('active');
}
function closeCreateModal(){
    document.getElementById('createModal').classList.remove('active');
}
async function confirmCreate(){
    const name=document.getElementById('newRoomName').value.trim();
    const desc=document.getElementById('newRoomDesc').value.trim();
    if(!name){ alert('채팅방 이름을 입력해주세요.'); return; }
    if(!desc){ alert('채팅방 설명을 입력해주세요.'); return; }
    const newRoom = await ChatAPI.createRoom(name, desc);
    closeCreateModal();
    await refreshRooms();
    await openRoom(newRoom.id);
    alert('채팅방이 생성되었습니다!');
}

async function renderUsers(){
    const res = await ChatAPI.listUsers();
    const online=document.getElementById('onlineList'), offline=document.getElementById('offlineList');
    online.innerHTML = offline.innerHTML = '';
    (res.online||[]).forEach(n => {
        const row=document.createElement('div');
        row.className='user-item';
        row.innerHTML=`<span class="dot online"></span><div class="user-name">${n}</div><span class="pill">온라인</span>`;
        online.appendChild(row);
    });
    (res.offline||[]).forEach(n => {
        const row=document.createElement('div');
        row.className='user-item';
        row.innerHTML=`<span class="dot offline"></span><div class="user-name">${n}</div><span class="pill">오프라인</span>`;
        offline.appendChild(row);
    });
}
