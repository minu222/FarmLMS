// 서버 연동 어댑터 (REST + STOMP)
window.ChatAPI = (function(){
    let stomp = null, sub = null;

    function connect(roomId, onMessage){
        return new Promise((resolve,reject)=>{
            if(stomp && stomp.connected){
                if(sub) sub.unsubscribe();
                sub = stomp.subscribe(`/topic/room.${roomId}`, f => onMessage(JSON.parse(f.body)));
                return resolve();
            }
            const sock = new SockJS('/ws');
            stomp = Stomp.over(sock);
            stomp.connect({}, () => {
                sub = stomp.subscribe(`/topic/room.${roomId}`, f => onMessage(JSON.parse(f.body)));
                resolve();
            }, (err) => reject(err));
        });
    }

    return {
        listRooms: () => fetch('/chat/api/rooms').then(r=>r.json()),
        listUsers: () => fetch('/chat/api/users').then(r=>r.json()),
        getMessages: (roomId, limit=50) => fetch(`/chat/api/rooms/${roomId}/messages?limit=${limit}`).then(r=>r.json()),
        joinRoom: (roomId) => fetch(`/chat/rooms/${roomId}/join`, {method:'POST'}),
        leaveRoom: (roomId) => fetch(`/chat/rooms/${roomId}/leave`, {method:'POST'}),
        createRoom: (name, desc) => fetch('/chat/rooms', {
            method:'POST',
            headers:{'Content-Type':'application/x-www-form-urlencoded'},
            body: new URLSearchParams({name, description: desc})
        }).then(r=>r.json()),
        sendMessage: (roomId, text) => {
            if(!stomp || !stomp.connected) return Promise.reject('WS not connected');
            stomp.send(`/app/room.${roomId}.send`, {}, JSON.stringify({roomId, content:text}));
            return Promise.resolve({ok:true});
        },
        subscribeRoom: (roomId, onMessage) => {
            return connect(roomId, onMessage).then(()=>({
                unsubscribe: ()=> { if(sub) sub.unsubscribe(); }
            }));
        }
    };
})();
